
Once inside lab1-wilgan-marta directory

to compile
javac linker.java

to run
java linker <absolute path to one of the input files>

linker.java - implements a two pass linker
Instruction.java - a class that defines a type Instruction
Symbol.java - a class that defines a type symbol
Module.java - a class that defines a type module

