
Once inside lab3-wilgan-marta directory

to compile 
javac manager.java

to run
java manager <absolute path to one of the input files>

to run with detailed information use verbose flag
java manager --verbose <absolute path to one of the input files>

manager.java - simulates resource allocation using both optimistic and banker's algorithm
Activity.java - a class that defines a type Activity
Resource.java - a class that defines a type Resource
Task.java - a class that defines a type Task