Once inside lab2-wilgan-marta directory

to compile
gcc -std=c99 main.c

to run
./a.out <absolute path of one of the input files> <absolute path of random numbers file>

to run with detailed output
./a.out --verbose <absolute path of one of the input files> <absolute path of random numbers file>

main.c - implements the scheduling of input with algorithms : 
First Come First Serve
Round Robin with quantum of 2
Uniprogrammed
Shortest Job First

