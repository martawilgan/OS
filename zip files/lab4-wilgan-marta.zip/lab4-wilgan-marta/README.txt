
Once inside lab4-wilgan-marta directory

to compile
javac Pager.java

to run
java Pager <inputs M P S J N R D> <absolute path of random numbers file>

to change level of debugging
D = 1, shows debugging output   
D = 2, shows D = 1 with random numbers as well

Pager.java - simulates demand paging 
Process.java - a class that defines a type Process
Frame.java - a class that defines a type Frame